class Node implements Comparable<Node>
{
	public final int name;    // Node’s name
	public Edge[] neighbors;  // set of neighbors to this node
	public double minDistance = Double.POSITIVE_INFINITY; //Minimum weight
	public Node previous;     // to keep the path
	public Node(int argName)  // constructor to create an instance of this class
	{ 
		name = argName; 
	}

	public int compareTo(Node other)
	{
		return Double.compare(minDistance, other.minDistance);
	}
}



class Edge
{
	public final Node target;  // destination node
	public final double weight; // the delay, in ms
	public Edge(Node argTarget, double argWeight) //constructor to create an instance 
	{ 
		target = argTarget;
		weight = argWeight; 
	}
}