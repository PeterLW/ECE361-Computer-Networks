import java.io.*;
import java.net.Socket;

public class Listener implements Runnable {
	
	//BufferedReader socketInput = null; // Input from the server
	public Socket listener_socket;
	int packets = 0;
	
	public Listener(Socket socket, int numPackets) {
		
		this.listener_socket = socket;
		packets = numPackets;
	}

	@Override
	public void run() {

		BufferedReader reader = null;
		try {reader = new BufferedReader(new InputStreamReader(listener_socket.getInputStream()));}
		catch(IOException e) {e.printStackTrace();}
		
		while(true) {
			
			try {
				
				// If the server has sent a message, read it
				if(reader.ready()) {
					
					//these commented out lines didn't work with testing lab4, not sure if because they sent int instead of string?
					String ack = reader.readLine();
					int ack_num = Integer.parseInt(ack);
					System.out.println("Received ACK #: " + ack_num);
					//Client.setAckNum(ack_num);
					if(ack_num > Client.lastAck) Client.lastAck = ack_num; 
					
					// Check if done
					if(ack_num == packets) {
						
						//Client.finish();
						Client.finished = true;
						break;
					}
				}
			}
			catch(IOException e) {
				
				e.printStackTrace();
			}
		}
	}
}