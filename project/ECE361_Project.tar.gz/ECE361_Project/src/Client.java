import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.*;

public class Client {
	
	static String mode;
	static String host;
	static int port;
	
	
	public static void adjacencyToEdges(double[][] matrix, List<Node> v) {
		
		for(int i = 0; i < matrix.length; i++) {
			
			v.get(i).neighbors = new Edge[matrix.length];
			for(int j = 0; j < matrix.length; j++) {
				
				v.get(i).neighbors[j] = new Edge(v.get(j), matrix[i][j]);
			}
		}
	}
	
	
	public static void computePaths(Node source) {
		
		source.minDistance = 0;
		PriorityQueue<Node> NodeQueue = new PriorityQueue<Node>();
		NodeQueue.add(source);
		
		while(NodeQueue.size() != 0) {
			
			Node sourceNode = NodeQueue.poll();
			
			for(int i = 0; i < sourceNode.neighbors.length; i++) {
				
				Node targetNode = sourceNode.neighbors[i].target;
				double distanceThroughSource = sourceNode.minDistance + sourceNode.neighbors[i].weight;
				
				if(distanceThroughSource < targetNode.minDistance) {
					
					NodeQueue.remove(targetNode);
					targetNode.minDistance = distanceThroughSource;
					targetNode.previous = sourceNode;
					NodeQueue.add(targetNode);
				}
			}
		}
	}
	
	
	public static List<Integer> getShortestPathTo(Node target, Node source) {
		
		List<Integer> path = new ArrayList<Integer>();
		path.add(target.name);
		Node prev;
		if(target.name != source.name) prev = target.previous;
		else prev = null;

		while(prev != null) {
			
			if(prev.name == source.name) {
				
				path.add(prev.name);
				break;
			}
			path.add(prev.name);
			prev = prev.previous;
		}
		
		List<Integer> reverse_path = new ArrayList<Integer>();
		for(int i = path.size() - 1; i >= 0; i--) reverse_path.add(path.get(i));
		
		return reverse_path;
	}

	
	
	
	
	
	
	
	/**** THREAD STUFF ****/
	
	static int lastAck = 0; // Used by AckListener to update latest ACK#
	static boolean finished = false; // Used by AckListener to indicate it is finished	
	
	public static void setAckNum(int ackNum)
	{
		if(ackNum > lastAck) lastAck = ackNum;
		//System.out.println("Setting last ACK to " + lastAck);
	}
	
	public static void finish()
	{
		finished = true;
	}
	
	/*********************/
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		
		if(args.length <= 0) {
			
			mode = "client";
			host = "localhost";
			port = 9876;
		}
		else if(args.length == 1) {
			
			mode = args[0];
			host = "localhost";
			port = 9876;
		}
		else if(args.length == 3) {
			
			mode = args[0];
			host = args[1];
			port = Integer.parseInt(args[2]);
		}
		else {
			
			System.out.println("Improper number of arguments.");
			return;
		}

		
		try {
			
			Socket socket = null;
			if(mode.equalsIgnoreCase("client")) {
				
				socket = new Socket(host, port);
			}
			else if(mode.equalsIgnoreCase("server")) {
				
				ServerSocket ss = new ServerSocket(port);
				socket = ss.accept();
			}
			else {
				
				System.out.println("Improper type.");
				return;
			}
			System.out.println("Connected to : " + host + ":" + socket.getPort());
			
			//reader and writer:
			BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream())); //for reading lines
			BufferedReader terminal = new BufferedReader(new InputStreamReader(System.in)); //to get user input
			DataOutputStream writer = new DataOutputStream(socket.getOutputStream());	//for writing lines.
			
			
			/************************************** START BY IMPLEMENTING DIJKSTRA'S ********************************************/
			
			double time_one_way = 0;
			while((socket != null) && socket.isConnected() && !socket.isClosed()) {
				
				System.out.println("Enter number of nodes in the network from server ");
				String str_noNodes = reader.readLine();
				int noNodes = Integer.parseInt(str_noNodes);			
				
						
				System.out.println(noNodes + " nodes");
				System.out.println();
				// Send noNodes to the server, and read a String from it containing adjacency matrix
				//writer.write(noNodes);
				
				// Create an adjacency matrix
				double[][] matrix = new double[noNodes][noNodes];
				String line = reader.readLine();
				StringTokenizer str = new StringTokenizer(line);
				
				System.out.println("ADJACENCY MATRIX");
				for (int ind1 = 0; ind1 < noNodes; ind1++) {
				    
					// Use StringTokenizer to store the values read from the server in matrix					
					for(int ind2 = 0; ind2 < noNodes; ind2++) {
						
						String next = str.nextToken();
						if(next == "Infinity") matrix[ind1][ind2] = Double.POSITIVE_INFINITY;
						else matrix[ind1][ind2] = Double.parseDouble(next);
					}
				}
				
				for(int i = 0; i < noNodes; i++) {
					for(int j = 0; j < noNodes; j++) System.out.print(matrix[i][j] + " ");
					
					System.out.println();
				}
				System.out.println();
					

				//The nodes are stored in a list, nodeList
				List<Node> nodeList = new ArrayList<Node>();
				for(int i = 0; i < noNodes; i++) {
					
					nodeList.add(new Node(i));
					nodeList.get(i).previous = null;
				}
				
				adjacencyToEdges(matrix, nodeList); // Create edges from adjacency matrix
				
				//computePaths from node 0 only
				computePaths(nodeList.get(0));
				System.out.println("From Node 0");
					
				//getShortestPathTo
				for(int j = 0; j < noNodes; j++){
						
					List<Integer> path = getShortestPathTo(nodeList.get(j), nodeList.get(0));
						
					double time = 0;
					for(int n = 0; n < path.size()-1; n++) {		
						for(int m = 0; m < nodeList.size(); m++) {	
							if(path.get(n) == nodeList.get(m).name) {		
								for(int p = 0; p < nodeList.get(m).neighbors.length; p++) {			
									if(path.get(n+1) == nodeList.get(m).neighbors[p].target.name) {
												
										time += nodeList.get(m).neighbors[p].weight;
										break;
									}
								}
								break;
							}
						} 
					}
					System.out.println("Total time to reach node " + j + ": " + time + " ms, Path: " + path);
					if(j == noNodes - 1) {
						
						writer.writeBytes(path + "\r\n");
						time_one_way = time;
					}
				}
				System.out.println();			
				break;
			}
			/********************************************************************************************************************/
			
			
			
			
			/********************************************* NOW SEND THE PACKETS *************************************************/
			
			// Variables for TCP control and packet window
			double timeout = 2*time_one_way + 50; //fixed timeout interval for simplicity
			boolean slow_start = true;
			boolean drop = false;
			int cwnd = 1, RTT = 0, ssthresh = 128, startOfCwnd = 1, currentPacket = 1;
			long currentTime = 0, currentTimeOut = 0;
			long start_time, end_time;
			int seeker = 0; //can put this in listener section and make it global, with "..Location..": reset_point = 0;
			int numberOfPackets;
			BufferedInputStream file_reader = null;
			
			while(true) {
				
				// Wait for input from user with a file
				try {

					//request the file
					System.out.println("Please enter the file directory");
					String file_name = terminal.readLine();
					writer.writeBytes(file_name + "\r\n");
					if(file_name == "quit") {
						
						System.out.println("Quitting");
						break;
					}
					
					String current_directory = System.getProperty("user.dir");
					
					//FIGURE OUT DIRECTORY LATER??
					//file_reader = new BufferedReader(new FileReader(current_directory + "/src/" + file_name));
					//should just be able to do: = new FileInputStream(file_name);
					file_reader = new BufferedInputStream(new FileInputStream(current_directory + "/src/" + file_name));
					
					
					System.out.println("File exists, beginning transfer");
					
					//NEED TO GET FILE LENGTH
					//File file_name = File("JavaFileReader.java");
					//int fileLength = file_reader.length();
					File file = new File(current_directory + "/src/" + file_name);
					int fileLength = (int)file.length();
					System.out.println("Length of the file: " + String.valueOf(fileLength));
					
					numberOfPackets = (int)java.lang.Math.ceil(((double)fileLength)/1000);
					writer.writeBytes(String.valueOf(numberOfPackets) + "\r\n");
					System.out.println("Number of Packets: " + String.valueOf(numberOfPackets));
					
					
					//create thread for receiving ACKs
					Thread thread = new Thread(new Listener(socket, numberOfPackets));
					thread.start();
					start_time = System.currentTimeMillis();	
					
					// Process all packets
					while(true) {
						
						// Check if we can send another packet
						try {
							
							//update cwnd
							startOfCwnd = lastAck + 1;
							file_reader.mark(startOfCwnd*1000);
							
							//check if we passed the threshold
							if(cwnd >= ssthresh) slow_start = false;
							else slow_start = true;
							
							// Send all packets possible
							for(int i = currentPacket; i <= Math.min(startOfCwnd + cwnd - 1, numberOfPackets); i++, currentPacket++) {
								
								System.out.println("Sending packet #" + currentPacket); 
								
								try {
															
									byte[] bytes = new byte[1004]; 
									bytes[0] = (byte) (currentPacket >> 24);
									bytes[1] = (byte) (currentPacket >> 16);
									bytes[2] = (byte) (currentPacket >> 8);
									bytes[3] = (byte) (currentPacket);

									//only reading in 1000 bytes, because 4 bytes were appended to head
									int bytesRead = file_reader.read(bytes, 4, 1000);
									
									//update current location in file
									if(!drop){
										
										seeker += bytesRead;
									}else{
										//reset seeker back to original position
										file_reader.reset();
										seeker = startOfCwnd*1000;
										drop = false;
									}
									//send to server
									writer.write(bytes);
									writer.writeBytes("\r\n");
									
									//can't send more, wait to see if the ACKs come in
									if(seeker == fileLength) break;
								}
								catch (Exception e) {
								
									e.printStackTrace();
								}
								//if(lastAck == currentPacket) continue;
							}
							currentTimeOut = System.currentTimeMillis();
							currentTime = System.currentTimeMillis();
							
							// Wait for timeout or all ACKs
							while(((currentTime - currentTimeOut) < timeout) && ((lastAck + 1) < Math.min(startOfCwnd + cwnd, numberOfPackets))) {
								
								currentTime = System.currentTimeMillis();
							}
							
							// Check for a timeout
							if((currentTime - currentTimeOut) >= timeout) {
								
								//reset to start of window
								System.out.println("Timeout for packet #" + startOfCwnd + ". Restarting from " + (lastAck + 1));
								startOfCwnd = lastAck + 1; //isn't this the same value?
								currentPacket = startOfCwnd;
								ssthresh = ssthresh/2;
								cwnd = 1;
								file_reader.mark(startOfCwnd*1000);
								drop = true;
								RTT++;
							}
							
							// Check for all ACKs
							if((lastAck + 1) >= (startOfCwnd + cwnd)) {
								
								if(slow_start) cwnd = cwnd*2;
								else cwnd += 1;
								RTT++;
							}
						}
						catch(Exception e) {
							
							e.printStackTrace();
							break;
						}
						
						// Check if we are done sending all packets
						if((currentPacket > numberOfPackets) && (lastAck >= numberOfPackets)) {
							
							System.out.println("Done sending all data.");
							break;
						}
					}
					
					// Wait until other thread is done
					System.out.println("Finishing main thread, waiting for ACK listener thread to finish");
					while(!finished) {
						
						try {Thread.sleep(500);}
						catch(Exception e) {e.printStackTrace();}
					}
					end_time = System.currentTimeMillis();
					
					
					System.out.println("Total time to send all packets: " + (end_time - start_time));
					System.out.println("Total time in terms of RTT: " + RTT);
					
					file_reader.close();
				}
				catch (Exception e) {
			
					e.printStackTrace();
				}		
			}
			
			/********************************************************************************************************************/
			
			System.out.println("Quit");
			socket.close();
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		}
	}
}